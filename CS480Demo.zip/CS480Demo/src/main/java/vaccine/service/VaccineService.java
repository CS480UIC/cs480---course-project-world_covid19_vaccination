package vaccine.service;

import java.util.List;

import vaccine.dao.VaccineDao;
import vaccine.domain.Vaccine;
import vaccine.domain.Vaccine;

/**
 * logic functions such as register, login
 * @author changxin bai
 *
 */
public class VaccineService {
	private VaccineDao vaccineDao = new VaccineDao();
	
	/**
	 * register a user
	 * @param form
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void insert(Vaccine form) throws VaccineException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		
		// check the user name
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()!=null && people.getName().equals(form.getName())) throw new PeopleException("The people name already exists!");
		vaccineDao.add(form);
	}
	
	
public void delete() throws VaccineException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		
		// check the user name
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()==null && !(people.getName().equals(form.getName()))) throw new PeopleException("The people name does not exist!");
		vaccineDao.delete();
	}

public void update(Vaccine form) throws VaccineException, ClassNotFoundException, InstantiationException, IllegalAccessException{
	
	vaccineDao.update(form);
}
	
	
	/**
	 * Login function
	 * @param form
	 * @return
	 * @throws UserException 
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void read(Vaccine form) throws VaccineException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		vaccineDao.read(form);
		
	}
	
	
//	public void read(People form) throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException {
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()==null) throw new PeopleException("This person is not in the database");
//		
//		int ID = people.getID();
//		
//		if(ID!=0 && !(ID==form.getID()))
//			throw new PeopleException(" The ID is not right");
//				
//	}
	
	
	public List<Object> findall() throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		return vaccineDao.findall();
		
	}
}
