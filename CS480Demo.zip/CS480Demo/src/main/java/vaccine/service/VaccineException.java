package vaccine.service;

public class VaccineException extends Exception {

	public VaccineException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public VaccineException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
