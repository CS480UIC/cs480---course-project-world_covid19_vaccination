package country.domain;

/**
 * User object
 * 
 * @author changxin bai
 * 
 */
public class Country {
	/*
	 * Correspond to the user table
	 */
	
	private String country_name; 
	private String country_abbreviation;
	private String vaccine_type;

	
	public String getCountryName() {
		return country_name;
	}

	public void setCountryName(String country_name) {
		this.country_name = country_name;
	}
	

	public String getCountryAbbreviation() {
		return country_abbreviation;
	}

	public void setCountryAbbreviation(String country_abbreviation) {
		this.country_abbreviation = country_abbreviation;
	}
	

	public String getVaccineType() {
		return vaccine_type;
	}

	public void setVaccineType(String vaccine_type) {
		this.vaccine_type = vaccine_type;
	}

	
	@Override
	public String toString() {
		return "Country[ country_name=" + country_name + ", country_abbreviation" + country_abbreviation +
				", vaccine_type=" + vaccine_type + "]";
	}
}
