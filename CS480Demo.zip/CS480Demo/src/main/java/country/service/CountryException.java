package country.service;

public class CountryException extends Exception {

	public CountryException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CountryException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
