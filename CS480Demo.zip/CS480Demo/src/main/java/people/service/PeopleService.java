package people.service;

import java.util.List;

import people.dao.PeopleDao;
import people.domain.People;

/**
 * logic functions such as register, login
 * @author changxin bai
 *
 */
public class PeopleService {
	private PeopleDao peopleDao = new PeopleDao();
	
	/**
	 * register a user
	 * @param form
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void insert(People form) throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		
		// check the user name
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()!=null && people.getName().equals(form.getName())) throw new PeopleException("The people name already exists!");
		peopleDao.add(form);
	}
	
	
public void delete() throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException{
		
		// check the user name
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()==null && !(people.getName().equals(form.getName()))) throw new PeopleException("The people name does not exist!");
		peopleDao.delete();
	}

public void update(People form) throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException{
	
	peopleDao.update(form);
}
	
	
	/**
	 * Login function
	 * @param form
	 * @return
	 * @throws UserException 
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void read(People form) throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		
		peopleDao.read(form);
		
	}
	
	
//	public void read(People form) throws PeopleException, ClassNotFoundException, InstantiationException, IllegalAccessException {
//		People people = peopleDao.findByName(form.getName());
//		if(people.getName()==null) throw new PeopleException("This person is not in the database");
//		
//		int ID = people.getID();
//		
//		if(ID!=0 && !(ID==form.getID()))
//			throw new PeopleException(" The ID is not right");
//				
//	}
	
	
	public List<Object> findall() throws InstantiationException, IllegalAccessException, ClassNotFoundException{
		return peopleDao.findall();
		
	}
}
