package people.service;

public class PeopleException extends Exception {

	public PeopleException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PeopleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
