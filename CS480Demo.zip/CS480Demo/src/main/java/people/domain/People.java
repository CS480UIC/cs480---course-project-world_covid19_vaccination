package people.domain;

/**
 * User object
 * 
 * @author changxin bai
 * 
 */
public class People {
	/*
	 * Correspond to the user table
	 */
	
	private int number;
	private String hospital_name;
	private int ID; 
	private String name;
	private int age;
	private String date_of_birth;
	

	
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	public String getHospitalName() {
		return hospital_name;
	}

	public void setHospitalName(String hospital_name) {
		this.hospital_name = hospital_name;
	}

	public int getID() {
		return ID;
	}

	public void setID(int ID) {
		this.ID = ID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getDateOfBirth() {
		return date_of_birth;
	}

	public void setDateOfBirth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	
	@Override
	public String toString() {
		return "People[ number=" + number + ", hospital_name" + hospital_name +
				", ID=" + ID + ", name=" + name + ", age=" 
				+ age + ", date_of_birth=" + date_of_birth + "]";
	}
}
