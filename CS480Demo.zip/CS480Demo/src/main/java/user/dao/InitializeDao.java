package user.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.domain.User;



/**
 * DDL functions performed in database
 * @author changxin bai
 *
 */
public class InitializeDao {
	
	
	/**
	 * get the search result with username 
	 * @param username
	 * @return
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public void initDB() {
		Statement statement;
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
			Connection connect = DriverManager
			          .getConnection("jdbc:mysql://localhost:3306/bookstore?"
				              + "user=root&password=ye521zd66");
			statement = connect.createStatement();
	        statement.executeUpdate("DROP TABLE IF EXISTS Country");
			String sqlstmt= "CREATE TABLE country (\r\n "+
					"country_name              VARCHAR(30) NOT NULL, \r\n"+
					"country_abbreviation      VARCHAR(10) NOT NULL, \r\n"+
					"vaccine_type   		  	  VARCHAR(30) NOT NULL, \r\n"+
					"PRIMARY KEY (country_name))";
			statement.executeUpdate(sqlstmt);
		   
		} catch(SQLException e) {
			throw new RuntimeException(e);
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
